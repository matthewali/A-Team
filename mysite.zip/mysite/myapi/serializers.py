#serializers.py
from rest_framework import serializers

from .models import BookDetails
from .models import Author


class BookSerializer (serializers.HyperlinkedModelSerializer):
	AuthorID = serializers.RelatedField(source = 'Author', read_only=True)
	
	class Meta:
		model = BookDetails
		fields =('Price','CopiesSold','AuthorID')
		
