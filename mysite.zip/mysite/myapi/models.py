from django.db import models

class Book(models.Model):
	ISBN = models.CharField(max_length=60)
	Title = models.CharField(max_length=60)
	Description = models.CharField(max_length=60)
	PublishDate = models.DateField()
	def __str__(self):
		return self.Title
class Genre(models.Model):
	GenreID = models.CharField(max_length=60)
	Type = models.CharField(max_length=60)
	def __str__(self):
		return self.Type
class Publisher(models.Model):
	PublisherID = models.CharField(max_length=60)
	Name = models.CharField(max_length=60)
	def __str__(self):
		return self.Name
class Author(models.Model):
	AuthorID = models.CharField(max_length=60)
	FName = models.CharField(max_length=60)
	LName = models.CharField(max_length=60)
	Biography = models.CharField(max_length=60)
	def __str__(self):
		return self.FName
class BookDetails(models.Model):
	Price = models.CharField(max_length=60)
	CopiesSold = models.CharField(max_length=60)
	ISBN = models.ForeignKey(Book, on_delete=models.CASCADE)
	GenreID = models.ForeignKey(Genre, on_delete=models.CASCADE)
	PublisherID = models.ForeignKey(Publisher, on_delete=models.CASCADE)
	AuthorID = models.ForeignKey(Author, on_delete=models.CASCADE)
	
	def __str__(self):
		return self.Price
